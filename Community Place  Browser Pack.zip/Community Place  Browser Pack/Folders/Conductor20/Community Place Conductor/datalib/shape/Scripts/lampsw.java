/*
 * Copyright(C) 1996, 1997 Sony Corporation. All rights reserved.
 */

import vrml.*;
import vrml.node.*;
import vrml.field.*;

public class lampsw extends Script {
	// Declare eventOut field(s)
	// CPC_VER_DECL begin
	private SFColor m_LampMaterialEmissiveColor;
	private SFColor m_ShadeMaterialEmissiveColor;
	private SFBool m_LampPointLightOn;
	// CPC_VER_DECL end

	boolean m_LightSw;

	// Declare initialize()
	public void initialize() {
		// This method is called ..
		try{
			// CPC_INIT begin
			m_LampMaterialEmissiveColor = (SFColor)getEventOut("LampMaterialEmissiveColor");
			m_ShadeMaterialEmissiveColor = (SFColor)getEventOut("ShadeMaterialEmissiveColor");
			m_LampPointLightOn = (SFBool)getEventOut("LampPointLightOn");
			// CPC_INIT end

			m_LightSw = false;

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	// Declare shutdown()
	public void shutdown() {
		try{
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	// CPC_HANDLER begin
	private void _LampTouchSensorIsActiveCB(ConstSFBool ev) {
		float lamp_col1[] = {1.0f,0.9f,0.8f};
		float lamp_col2[] = {0.1f,0.1f,0.1f};
		float shade_col1[] = {0.7f,0.6f,0.5f};
		float shade_col2[] = {0.0f,0.0f,0.0f};

		if (ev.getValue()) {	/* mouseDown */
			if (m_LightSw) {
				m_LampMaterialEmissiveColor.setValue( lamp_col1 );
				m_ShadeMaterialEmissiveColor.setValue( shade_col1 );

			} else {
				m_LampMaterialEmissiveColor.setValue( lamp_col2 );
				m_ShadeMaterialEmissiveColor.setValue( shade_col2 );
			}
			m_LampPointLightOn.setValue( m_LightSw );

			m_LightSw = !m_LightSw;
		}
	}
	// CPC_HANDLER end

	// Declare processEvents field
	public void processEvents(int count, Event events[]) {
		// This method is called 
		try{
			for (int i = 0; i < count; i++) {
				// CPC_EVENT begin
			if (events[i].getName().equals("LampTouchSensorIsActive"))
				_LampTouchSensorIsActiveCB((ConstSFBool)events[i].getValue());
				// CPC_EVENT end
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	} // end of processEvents() 
} // end of class lampsw 
