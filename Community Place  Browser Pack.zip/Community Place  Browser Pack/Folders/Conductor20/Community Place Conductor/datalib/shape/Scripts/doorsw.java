/*
 * Copyright(C) 1996, 1997 Sony Corporation. All rights reserved.
 */

import vrml.*;
import vrml.node.*;
import vrml.field.*;

public class doorsw extends Script {
	// Declare eventOut field(s)
	// CPC_VER_DECL begin
	private SFTime m_DoorOpenTimeSensorStartTime;
	private SFTime m_DoorCloseTimeSensorStartTime;
	private SFTime m_DoorAudioClipStartTime;
	private SFTime m_DoorKnockAudioClipStartTime;
	// CPC_VER_DECL end

	private boolean m_DoorClosed;

	// Declare initialize()
	public void initialize() {
		// This method is called ..
		try{
			// CPC_INIT begin
			m_DoorOpenTimeSensorStartTime = (SFTime)getEventOut("DoorOpenTimeSensorStartTime");
			m_DoorCloseTimeSensorStartTime = (SFTime)getEventOut("DoorCloseTimeSensorStartTime");
			m_DoorAudioClipStartTime = (SFTime)getEventOut("DoorAudioClipStartTime");
			m_DoorKnockAudioClipStartTime = (SFTime)getEventOut("DoorKnockAudioClipStartTime");
			// CPC_INIT end

			m_DoorClosed = true;

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	// Declare shutdown()
	public void shutdown() {
		try{
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	// CPC_HANDLER begin
	private void _KnobTouchSensorIsActiveCB(ConstSFBool ev, double time) {
		if(!ev.getValue()){
			if(m_DoorClosed)
				m_DoorOpenTimeSensorStartTime.setValue(time);
			else
				m_DoorCloseTimeSensorStartTime.setValue(time);

			m_DoorClosed = !m_DoorClosed;
			m_DoorAudioClipStartTime.setValue(time);
		}
	}
	private void _DoorPanelTouchSensorIsActiveCB(ConstSFBool ev, double time) {
		if(ev.getValue())
			m_DoorKnockAudioClipStartTime.setValue(time);
			
	}
	// CPC_HANDLER end

	// Declare processEvents field
	public void processEvents(int count, Event events[]) {
		// This method is called 
		try{
			for (int i = 0; i < count; i++) {
				// CPC_EVENT begin
				if (events[i].getName().equals("KnobTouchSensorIsActive"))
					_KnobTouchSensorIsActiveCB((ConstSFBool)events[i].getValue(), (double)events[i].getTimeStamp());
			if (events[i].getName().equals("DoorPanelTouchSensorIsActive"))
				_DoorPanelTouchSensorIsActiveCB((ConstSFBool)events[i].getValue(), (double)events[i].getTimeStamp());
				// CPC_EVENT end
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	} // end of processEvents() 
} // end of class doorsw 
