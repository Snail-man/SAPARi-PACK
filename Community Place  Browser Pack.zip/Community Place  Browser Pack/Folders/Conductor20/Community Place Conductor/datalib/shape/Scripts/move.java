/*
 * Copyright(C) 1996, 1997 Sony Corporation. All rights reserved.
 */

import vrml.*;
import vrml.node.*;
import vrml.field.*;

public class move extends Script {
	// Declare eventOut field(s)
	// CPC_VER_DECL begin
	private SFTime m_Move1TimeSensorStartTime;
	private SFTime m_Move2TimeSensorStartTime;
	// CPC_VER_DECL end

	boolean m_initialPosition;

	// Declare initialize()
	public void initialize() {
		// This method is called ..
		try{
			// CPC_INIT begin
			m_Move1TimeSensorStartTime = (SFTime)getEventOut("Move1TimeSensorStartTime");
			m_Move2TimeSensorStartTime = (SFTime)getEventOut("Move2TimeSensorStartTime");
			// CPC_INIT end

			m_initialPosition = true;

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	// Declare shutdown()
	public void shutdown() {
		try{
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	// CPC_HANDLER begin
	private void _MoveTouchSensorIsActiveCB(ConstSFBool ev, double time) {
		if(ev.getValue()){
			if(m_initialPosition)
				m_Move1TimeSensorStartTime.setValue(time);
			else
				m_Move2TimeSensorStartTime.setValue(time);

			m_initialPosition = !m_initialPosition;
		}
	}
	// CPC_HANDLER end

	// Declare processEvents field
	public void processEvents(int count, Event events[]) {
		// This method is called 
		try{
			for (int i = 0; i < count; i++) {
				// CPC_EVENT begin
				if (events[i].getName().equals("MoveTouchSensorIsActive"))
					_MoveTouchSensorIsActiveCB((ConstSFBool)events[i].getValue(), (double)events[i].getTimeStamp());
				// CPC_EVENT end
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	} // end of processEvents() 
} // end of class move 
