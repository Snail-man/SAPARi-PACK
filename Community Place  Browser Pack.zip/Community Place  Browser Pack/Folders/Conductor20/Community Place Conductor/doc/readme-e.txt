----------------------------------------------------------------------
                Community Place Conductor Version 2.0
----------------------------------------------------------------------

Preface
~~~~~~~
Community Place Conductor ("Conductor" in the following pages) is the 
authoring tool that conforms to VRML 2.0.  Conductor 2.0 has the 
following features: 

    - Conforms to VRML 2.0. 
    - Drag and drop to add a node. 
    - Enables you to specify values for node attributes. 
    - Enables you to specify textures for sound and objects. 
    - Enables you to switch between the Execution and Edit modes. 
    - Conforms to Java (JRE1.1.3, JDK1.1.3, or later). 
    - Enables you to edit independently in each scope by switching 
      the current scope. 
    - The Script Expert function to automatically create a script node. 
    - Enables you to add/delete routing while displaying it on the screen. 
    - Enables you to edit keyframes. 
    - Enables you to edit PROTO. 
    - Supports USE. 

This manual describes each function of Conductor. For informations on
how to create a world with Conductor, see Tutorial. 

Note: RenderWare is used for the 3D graphic engine.


System Requirements
~~~~~~~~~~~~~~~~~~~
Before starting Conductor, check to see if your system meets the 
following requirements.

* Recommended Environment *

    HARDWARE: PC/AT-compatible machines operated under Windows 95/98/NT4.0.
    CPU: Pentium 90MHz or higher
    RAM: 32MB or more
    Free disk space: 40MB or more
    Display resolution: 800x600 pixels or higher
    Display colors: 65536 colors or more
    Sound: Sound board + a speaker or headphones
    Software: 
        Netscape Navigator ver3.0 or later or Internet Explorer ver3.0 or later:
            Necessary when displaying online help.
        JDK 1.1.x or JRE 1.1.x: 
            Necessary when creating contents that use JAVA.
            JDK is required when compiling the scripts, but JRE could be used 
            for confirming the scripts.
        Adobe Acrobat Reader ver3.x: 
            Necessary when viewing manuals and tutorials that are in PDF format. 


Installing Conductor
~~~~~~~~~~~~~~~~~~~~
Execute conductor\setup.exe in the Conductor CD-ROM to install Conductor.


Uninstalling Conductor
~~~~~~~~~~~~~~~~~~~~~~
You can easily and safely uninstall Conductor in the following 
procedure: 

    1.Click the Start button. 
    2.Open Program, and select Community Place Conductor. 
    3.Select Uninstall from the menu. 

Note: A part of the temporary files or the files you created after 
installing Conductor may not be deleted by uninstalling Conductor. 
In such a case, delete all the Conductor directories left. 
Before re-installing Conductor, make sure that all the Conductor 
directories are completely deleted.


Folders
~~~~~~~
The following folders are created after installing Conductor.

    bin\     Conductor and the DLL's used by Conductor are placed here.
    datalib\ Scripts, Textures, Sounds, etc that are provided for the 
             Conductor's Library are placed here.
    doc\     Documents such as manuals andtutorials are here.
    lib\     Runtime libraries and other liraries are here.
    tmp\     Used to place temporary files.
    Users\   User's files are here.


Restrictions
~~~~~~~~~~~~
Please refer to doc\restrict\index-e.html under Conductor's directory
for restrictions.


Using Conductor
~~~~~~~~~~~~~~~
Please refer to the manual for operating Conductor.
To open the manual, Click Start button on the task bar, select
Program, and click Manual under Community Place Conductor.


Others
~~~~~~
For more informations on bugs, new version, and free beta releases,
please visit the "Virtual Society on the Web" home page:
http://vs.sony.co.jp/


Trademarks
~~~~~~~~~~
 - Community Place is the trademark of Sony Corporation.
 - Microsoft Windows, Windows NT, and Internet Explorer are registered
   trademarks of Microsoft Corporation in the United States of America
   and other countries.
 - RenderWare is the registered trademark of Canon Incorporated.
 - Netscape Navigator is the trademark of Netscape Communications 
   Corporation in the United States.
 - Adobe Acrobat is the trademark of Adobe Systems Incorporated.
 - Other product and company names mentioned herein may be the trademarks 
   or registered trademarks of their respective owners. 


Copyright (C) 1998 Sony Corporation.  All rights reserved.
