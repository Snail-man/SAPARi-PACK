//
// avatar.java
//	for Forest Park avatars
//	'96.12.26
// (c) Copyright 1996 Sony Corporation. All rights reserved.

import vs.*;
import vrml.*;
import vrml.field.*;
import vrml.node.*;

public class avatar extends Script {
	final int PARTS_MAX = 6;
	final int COLOR_MAX = 8;
	private boolean avatarStatus = true;
	
    private SFFloat  value; 
    private SFTime helloStart;
    private SFTime smileStart;
    private SFTime woooStart;
    private SFTime waoStart;
    private SFTime ummStart;
    private SFTime sadStart;
    private SFTime byeStart;
    private SFTime sleepStart;
    private SFTime activeStart;
    private SFTime walkStart;
    private SFBool winkLoop;
    private SFTime vchatStart;
    private SFTime vchatStop;

    private SFBool timerOn;
    private SFTime timerStart;
    private SFBool timerwOn;
    private SFTime timerwStart;
    private MFVec3f avatarTrans;
    private SFVec3f avatarDirect;
    private SFRotation avatarRot;

    private static String ActionList[] = {
        "Hello",
        "Smile",
        "Wao",
        "Umm",
        "Wooo",
        "Sad",
        "Bye", 
        "Sleep",
        "Normal", };
    private static String SpeakList[] = {
        "vc_enabled",
        "vc_disabled",
        "vc_nofunction",
        "vc_sepak_on",
        "vc_speak_off", };
   

   
    private float tmpArray[][];
    private float oldPositionArray[];
    private double vector[];
    private float dist[];
    private double length;
    private boolean start = true;
    private boolean sleepflg = false;
    private int parity = 0;
    private int flag = 0;
    private int counter = 0;   

  private SFColor partsColor[] = new SFColor[PARTS_MAX];
  private SFVec3f partsScale[] = new SFVec3f[PARTS_MAX];

	final int cBase = '0';
   public void initialize() {
	String str;

        value =  (SFFloat) getEventOut("value");
        helloStart = (SFTime) getEventOut("Act0_Start");
        smileStart = (SFTime) getEventOut("Act1_Start");
        woooStart = (SFTime) getEventOut("Act2_Start");
        waoStart = (SFTime) getEventOut("Act3_Start");
        ummStart = (SFTime) getEventOut("Act4_Start");
        sadStart = (SFTime) getEventOut("Act5_Start");
        byeStart = (SFTime) getEventOut("Act6_Start");
        walkStart = (SFTime) getEventOut("Walk_Start");

        sleepStart = (SFTime) getEventOut("Sleep_Start");
        activeStart = (SFTime) getEventOut("Active_Start");
	winkLoop = (SFBool) getEventOut("Wink_Loop");

        timerOn   = (SFBool) getEventOut("timerOn");
        timerStart = (SFTime) getEventOut("timerStart");
        timerwOn   = (SFBool) getEventOut("timerwOn");
        timerwStart = (SFTime) getEventOut("timerwStart");
        avatarTrans = (MFVec3f) getEventOut("avatarTrans");
        avatarDirect = (SFVec3f) getEventOut("avatarDirect");
        avatarRot = (SFRotation) getEventOut("avatarRot");
        vchatStart = (SFTime) getEventOut("vchatStart");
        vchatStop = (SFTime) getEventOut("vchatStop");

	for( int i = 0; i < PARTS_MAX; i++ ){
		partsColor[i] = (SFColor) getEventOut( "partsColor" + i );
		partsScale[i] = (SFVec3f) getEventOut( "partsScale" + i );
	}

        tmpArray = new float[2][3];
	oldPositionArray = new float[3];
        vector = new double[3];
        dist = new float[3];

   }

   public void timeOut(ConstSFTime t, double now) {
       if(parity == 1) {
           sleepflg = false;
           parity = 0;
       } else if ( sleepflg == false) {
           parity = 0;
       } else {
           parity = 1;
       }      
   }

   public void sonyAvatarPosture(ConstSFString action, double t){
            String actionName = action.getValue();
       if (actionName.equals( ActionList[0])) {
           helloStart.setValue(t); 
       } else if ( actionName.equals( ActionList[1])) {
           smileStart.setValue(t); 
       } else if ( actionName.equals( ActionList[2])) {
           waoStart.setValue(t); 
       } else if ( actionName.equals( ActionList[3])) {
           woooStart.setValue(t); 
       } else if ( actionName.equals( ActionList[4])) {
           ummStart.setValue(t); 
       } else if ( actionName.equals( ActionList[5])) {
           sadStart.setValue(t); 
       } else if ( actionName.equals( ActionList[6])) {
           byeStart.setValue(t); 
       } else if ( actionName.equals( ActionList[7])) {
	sleepflg = true;
       } else if ( actionName.equals( ActionList[8])) {
	
       }

       if ( sleepflg  ) {
          timerStart.setValue(t);
          timerOn.setValue(start);
       }
    }
 
    public void timewOut(ConstSFTime t, double now) {
       if(counter == 1) {
           flag = 0;
       } else if (flag == 0) {
           counter = 0;
       } else {
           counter = 1;
       }     
    }
    
    //
    // voice chat function
    //
    public void sonyAvatarSpeak(ConstSFString speak, double t){
	   String speakName = speak.getValue();
       if (speakName.equals( SpeakList[0])) {
	       vchatStart.setValue(t);
           System.out.println( "avatar voice chat state enabled"); 
       } else if (speakName.equals( SpeakList[1])) {
           vchatStop.setValue(t);          
           System.out.println( "avatar voice chat state disabled"); 
       } else if (speakName.equals( SpeakList[2])) {
           System.out.println( "avatar voice chat state nofunction");                 
       } else if (speakName.equals( SpeakList[3])) {
           System.out.println( "avatar voice chat Action start");  
       } else if (speakName.equals( SpeakList[4])) {
           System.out.println( "avatar voice chat Action stop");  
       } else { 
           System.out.println( "avatar voice chat state invalid string!!");                 
       }         
    }
    
    // sleep, color, scale
    //
    public void sonyAvatarAttribute(ConstSFString action, double t){
       String actionName = action.getValue();
       String colorstr = actionName.substring(8);

       if (actionName.startsWith("sleep:1 ")) {
		sleepStart.setValue( t );
		winkLoop.setValue( false );
		avatarStatus = false;
       } else {
		if( avatarStatus == false ) activeStart.setValue( t );
		winkLoop.setValue( true );
		avatarStatus = true;
       }
	// set avater color
	setColor( colorstr );
    }

    // set color to avater parts
    public void setColor ( String colorString ){
	String str;
	SFInt32 colorNo;
	float f[] = new float[ 3 ];

	// decode
	if ( colorString.length() < ( PARTS_MAX * 2 )){
		// default color
		System.out.println ( "default color "  );
	}
	else{
		System.out.println ( "set color,scale: " + colorString  );
		for ( int i = 0; i < PARTS_MAX; i++ ){
			int decode_color = (int) colorString.charAt( i * 2 ) - cBase;
			int decode_scale = (int) colorString.charAt( i * 2 + 1 ) - cBase;
			// set diffuse color
			if( decode_color < COLOR_MAX ){
				f = GenerateColor.getSFColor( decode_color );
				partsColor[ i ].setValue( f );
				System.out.println ( "color: " + f[0] );
			}
			float scale = GenerateColor.scale_table[ decode_scale ];
			float arg[] = { scale, scale, scale };
			partsScale[ i ].setValue(arg);
		}
	}
    }
    
    public void sonyAvatarVector(ConstMFVec3f avtPosition, double t){
	avtPosition.getValue(tmpArray);
	avatarDirect.setValue( tmpArray[1] );

	if(  oldPositionArray[0] != tmpArray[1][0] || 
		oldPositionArray[1] != tmpArray[1][1] ||
		oldPositionArray[2] != tmpArray[1][2] ){
		// walk animation
		if( avatarStatus ) walkStart.setValue(t); 
	}
	oldPositionArray[0] = tmpArray[1][0];
	oldPositionArray[1] = tmpArray[1][1];
	oldPositionArray[2] = tmpArray[1][2];
    }      
    public void processEvent(Event e) {
       String name = e.getName();

       if (name.equals("sonyAvatarPosture")) {
           sonyAvatarPosture((ConstSFString)e.getValue(), e.getTimeStamp());
       }
        else if (name.equals("sonyAvatarSpeak")) {
	   sonyAvatarSpeak((ConstSFString)e.getValue(), e.getTimeStamp());
       }
	else if (name.equals("sonyAvatarVector")) {
           sonyAvatarVector((ConstMFVec3f)e.getValue(), e.getTimeStamp());
       }
	 else if (name.equals("timeOut")) {
          timeOut((ConstSFTime)e.getValue(), e.getTimeStamp());
       }
	 else if (name.equals("timewOut")) {
          timewOut((ConstSFTime)e.getValue(), e.getTimeStamp());
       }
	 else if (name.equals("sonyAvatarAttribute")) {
           sonyAvatarAttribute((ConstSFString)e.getValue(), e.getTimeStamp());
      }

    }         

}

	






