Sony Community Place Browser / "SAPARi"

To install, run the "install.bat" file. All it does is copy the contents of browserData to a new folder at C:\Sony\Community Place Browser\.
By default, the .wrl files point the browser to use the server at kokoscript.com, where there is (hopefully) an active server. Be kind to others on the server, please!
If you would like to use a different server, use the included Server Setter tool.