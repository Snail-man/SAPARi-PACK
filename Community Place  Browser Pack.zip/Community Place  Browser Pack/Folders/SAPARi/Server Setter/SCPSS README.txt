HOW TO USE:

Step 1. - Make sure you run the program as administrator and don't have any files set as read-only in your Sapari Community Place game directory.

Step 2. - Select your Community Place Browser folder. (e.g. C:\Sony\Community Place Browser)

Step 3. - Type in the IP:Port or webhost of the server you want to connect to. E.g. "12.123.80.80:12345" or "www.mysapariserver.com:12345".

Step 4. - Run. The rest is handled automatically.

Step 5. - Launch the game and connect to the server.

Step 6. - Have fun!